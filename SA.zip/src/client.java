import demo1.*;
import demo2.*;
import demo3.*;
import demo4.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class client {
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException, InterruptedException {
        System.out.println("请选择一种方法对文件进行处理：");
        System.out.println(" “1” 代表 主程序-子程序软件体系结构 ");
        System.out.println(" “2” 代表 面向对象软件体系结构 ");
        System.out.println(" “3” 代表 事件系统软件体系结构 ");
        System.out.println(" “4” 代表 管道-过滤软件体系结构 ");
        Scanner sc = new Scanner(System.in);
        int input = sc.nextInt();
        Thread.sleep(5000);
        if (input == 1) {
            Class demoClass = Class.forName("demo1.demo1");
            Object demoObject = demoClass.newInstance();
        } else if (input == 2) {
            Class mainClass = Class.forName("demo2.Main");
            Object mainObject = mainClass.newInstance();

            Class inputClass = Class.forName("demo2.Input");
            Object inputObject = inputClass.newInstance();

            Class shiftClass = Class.forName("demo2.Shift");
            Object shiftObject = shiftClass.newInstance();

            Class alphabetizerClass = Class.forName("demo2.Alphabetizer");
            Object alphabetizerObject = alphabetizerClass.newInstance();

            Class outputClass = Class.forName("demo2.Output");
            Object outputObject = outputClass.newInstance();
        } else if (input == 3) {
            Class mainClass = Class.forName("demo3.Main");
            Object mainObject = mainClass.newInstance();

            Class inputClass = Class.forName("demo3.Input");
            Object inputObject = inputClass.newInstance();

            Class outputClass = Class.forName("demo3.Output");
            Object outputObject = outputClass.newInstance();

            Class shiftClass = Class.forName("demo3.Shift");
            Object shiftObject = mainClass.newInstance();

            Class alphabetizerClass = Class.forName("demo3.Alphabetizer");
            Object alphabetizerObject = mainClass.newInstance();

            Class KWICSubjectClass = Class.forName("demo3.KWICSubject");
            Object KWICSubjectObject = KWICSubjectClass.newInstance();

            Class SubjectClass = Class.forName("demo3.Subject");
            Object SubjectObject = SubjectClass.newInstance();

            Class ObserverClass = Class.forName("demo3.Observer");
            Object ObserverObject = ObserverClass.newInstance();
        } else if (input == 4) {
            Class mainClass = Class.forName("demo4.Main");
            Object mainObject = mainClass.newInstance();

            Class inputClass = Class.forName("demo4.Input");
            Object inputObject = inputClass.newInstance();

            Class outputClass = Class.forName("demo4.Output");
            Object outputObject = outputClass.newInstance();

            Class shiftClass = Class.forName("demo4.Shift");
            Object shiftObject = shiftClass.newInstance();

            Class alphabetizerClass = Class.forName("demo4.Alphabetizer");
            Object alphabetizerObject = alphabetizerClass.newInstance();

            Class PipeClass = Class.forName("demo4.Pipe");
            Object PipeObject = PipeClass.newInstance();

            Class FilterClass = Class.forName("demo4.Filter");
            Object FilterObject = FilterClass.newInstance();
        } else {
            System.out.println("输入错误！");
        }
    System.out.println("处理完成！！！");
    }
}