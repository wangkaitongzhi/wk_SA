package demo3;

public interface Observer {
    void toDo();
}

