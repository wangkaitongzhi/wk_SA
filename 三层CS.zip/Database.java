package shiyan3.三层CS;

import java.util.HashMap;
import java.util.Map;

public class Database {
    private static Map<String, String> contacts = new HashMap<>();

    public static String processRequest(String request) {
        String[] parts = request.split(" ");
        String operation = parts[0];
        String response;

        switch (operation) {
            case "ADD":
                String[] data = parts[1].split(",");
                String name = data[0].trim();
                String email = data[1].trim();
                String phone = data[2].trim();
                contacts.put(name, "Email: " + email + ", Phone: " + phone);
                response = "联系人添加成功。";
                break;
            case "GET":
                name = parts[1].trim();
                if (contacts.containsKey(name)) {
                    response = "联系人详情：" + contacts.get(name);
                } else {
                    response = "未找到联系人。";
                }
                break;
            case "DELETE":
                name = parts[1].trim();
                if (contacts.containsKey(name)) {
                    contacts.remove(name);
                    response = "联系人删除成功。";
                } else {
                    response = "未找到联系人。";
                }
                break;
            default:
                response = "无效操作。";
                break;
        }

        return response;
    }
}