package com.qst.crop.dao;

import com.qst.crop.entity.Bank;

import java.util.List;

public interface BankDao {

    List<Bank> selectAllBank();

}